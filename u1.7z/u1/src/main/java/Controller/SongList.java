package Controller;

import javafx.collections.ModifiableObservableListBase;

import java.util.ArrayList;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public class SongList extends ModifiableObservableListBase<Song> implements SongListInterface {

    ArrayList list = new ArrayList()<>;
}
