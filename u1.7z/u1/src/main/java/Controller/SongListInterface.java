package Controller;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public interface SongListInterface {
}
