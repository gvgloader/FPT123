package Controller;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public class Controller {
    private final Model model;

    public Controller(Model model) {

        this.model = model;
    }
}
