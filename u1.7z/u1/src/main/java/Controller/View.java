package Controller;

import javafx.scene.layout.BorderPane;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public class View extends BorderPane{

}
