package Controller;

import java.util.ArrayList;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public class Model {

    SongList lieder = new SongList();
    SongList playlist = new SongList();
}
