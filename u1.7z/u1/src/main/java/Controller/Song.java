package Controller;

/**
 * Created by sjalwieg on 12.05.2017.
 */
public class Song implements SongInterface {

    String pfad, titel, album, interpret;


}
